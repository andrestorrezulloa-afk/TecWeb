﻿using System.Threading.Tasks;
using TecWeb.Core.DTOs;
using TecWeb.Core.Services;

namespace TecWeb.Core.Interfaces
{
    public interface IUsuarioService
    {
        Task<ServiceResult<UsuarioDto>> CrearUsuarioAsync(UsuarioDto usuarioDto);
        Task<ServiceResult<UsuarioDto>> ActualizarUsuarioAsync(int id, UsuarioDto usuarioDto);
        Task<ServiceResult<bool>> EliminarUsuarioAsync(int id);
        Task<ServiceResult<UsuarioDto>> ObtenerUsuarioPorIdAsync(int id);
    }
}
