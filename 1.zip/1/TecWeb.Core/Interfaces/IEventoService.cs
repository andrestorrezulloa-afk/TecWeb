﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TecWeb.Core.DTOs;
using TecWeb.Core.Services;

namespace TecWeb.Core.Interfaces
{
    public interface IEventoService
    {
        Task<ServiceResult<EventoDto>> CrearEventoAsync(EventoDto eventoDto);
        Task<ServiceResult<EventoDto>> ActualizarEventoAsync(int id, EventoDto eventoDto);
        Task<ServiceResult<bool>> EliminarEventoAsync(int id);
        Task<ServiceResult<List<EventoDto>>> ListarEventosAsync();
        Task<ServiceResult<EventoDto>> ObtenerEventoPorIdAsync(int id);
    }
}
