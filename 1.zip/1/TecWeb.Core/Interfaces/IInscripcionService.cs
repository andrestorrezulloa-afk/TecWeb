﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TecWeb.Core.DTOs;
using TecWeb.Core.Services;

namespace TecWeb.Core.Interfaces
{
    public interface IInscripcionService
    {
        Task<ServiceResult<InscripcionDto>> CrearInscripcionAsync(InscripcionDto inscripcionDto);
        Task<ServiceResult<bool>> EliminarInscripcionAsync(int id);
        Task<ServiceResult<List<InscripcionDto>>> ListarInscripcionesPorEventoAsync(int eventoId);
        Task<ServiceResult<InscripcionDto>> ObtenerInscripcionPorIdAsync(int id);
    }
}
