﻿namespace TecWeb.Core;

public class Class1
{

}
