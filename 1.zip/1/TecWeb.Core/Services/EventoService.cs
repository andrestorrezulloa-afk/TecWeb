﻿using AutoMapper;
using TecWeb.Core.DTOs;
using TecWeb.Core.Entities;
using TecWeb.Core.Interfaces;

namespace TecWeb.Core.Services
{
    public class EventoService : IEventoService
    {
        private readonly IEventoRepository _eventoRepository;
        private readonly IMapper _mapper;

        public EventoService(IEventoRepository eventoRepository, IMapper mapper)
        {
            _eventoRepository = eventoRepository;
            _mapper = mapper;
        }

        public async Task<ServiceResult<EventoDto>> CrearEventoAsync(EventoDto eventoDto)
        {
            if (eventoDto == null) return ServiceResult<EventoDto>.Failure("Evento nulo.");

            var usuarioExiste = await _eventoRepository.UsuarioExisteAsync(eventoDto.UsuarioId);
            if (!usuarioExiste) return ServiceResult<EventoDto>.Failure("Usuario asignado no existe.");

            var conflicto = await _eventoRepository.ExisteConflictoAsync(eventoDto.UsuarioId, eventoDto.Fecha, eventoDto.Lugar);
            if (conflicto) return ServiceResult<EventoDto>.Failure("Ya existe un evento del mismo usuario en esa fecha y lugar.");

            var evento = _mapper.Map<Evento>(eventoDto);
            var creado = await _eventoRepository.CrearAsync(evento);

            return ServiceResult<EventoDto>.Success(_mapper.Map<EventoDto>(creado), "Evento creado");
        }

        public async Task<ServiceResult<EventoDto>> ActualizarEventoAsync(int id, EventoDto eventoDto)
        {
            var evento = await _eventoRepository.ObtenerPorIdAsync(id);
            if (evento == null) return ServiceResult<EventoDto>.Failure("Evento no encontrado.");

            var usuarioExiste = await _eventoRepository.UsuarioExisteAsync(eventoDto.UsuarioId);
            if (!usuarioExiste) return ServiceResult<EventoDto>.Failure("Usuario asignado no existe.");

            var dup = await _eventoRepository.ExisteConflictoAsync(eventoDto.UsuarioId, eventoDto.Fecha, eventoDto.Lugar, id);
            if (dup) return ServiceResult<EventoDto>.Failure("Existe otro evento del mismo usuario en esa fecha y lugar.");

            _mapper.Map(eventoDto, evento);
            await _eventoRepository.ActualizarAsync(evento);

            return ServiceResult<EventoDto>.Success(_mapper.Map<EventoDto>(evento), "Evento actualizado");
        }

        public async Task<ServiceResult<bool>> EliminarEventoAsync(int id)
        {
            var evento = await _eventoRepository.ObtenerPorIdAsync(id);
            if (evento == null) return ServiceResult<bool>.Failure("Evento no encontrado.");

            await _eventoRepository.EliminarAsync(evento);
            return ServiceResult<bool>.Success(true, "Evento eliminado");
        }

        public async Task<ServiceResult<List<EventoDto>>> ListarEventosAsync()
        {
            var eventos = await _eventoRepository.ListarAsync();
            return ServiceResult<List<EventoDto>>.Success(_mapper.Map<List<EventoDto>>(eventos));
        }

        public async Task<ServiceResult<EventoDto>> ObtenerEventoPorIdAsync(int id)
        {
            var evento = await _eventoRepository.ObtenerPorIdAsync(id);
            if (evento == null) return ServiceResult<EventoDto>.Failure("Evento no encontrado.");
            return ServiceResult<EventoDto>.Success(_mapper.Map<EventoDto>(evento));
        }
    }
}
