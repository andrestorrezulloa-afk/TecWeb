﻿namespace TecWeb.Infrastructure;

public class Class1
{

}
